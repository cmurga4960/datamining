# -*- coding: utf-8 -*-
"""
Created on Fri Mar 31 17:21:52 2017

@author: the4960
utep cs students pics
"""


from selenium import webdriver
from selenium.webdriver.common.keys import Keys
import time
import sys


email = "cmurga4960@gmail.com"
person = 'Martha'
url = 'https://www.facebook.com/martha.osegueda/'
max_scroll = 10000
users=[]

def find_between( s, first, last ):
    try:
        start = s.index( first ) + len( first )
        end = s.index( last, start )
        return s[start:end]
    except ValueError:
        return ""

def loginFB(email,passwd):
    driver = webdriver.Firefox()
    driver.get("http://www.facebook.com/login")
    
    if "Facebook" == driver.title:
        return driver
    login = 'Log into Facebook | Facebook'
    assert login in driver.title
    elem = driver.find_element_by_name("email")
    elem.clear()
    elem.send_keys(email)
    elem = driver.find_element_by_name("pass")
    elem.clear()
    elem.send_keys(passwd)
    elem.send_keys(Keys.RETURN)
    tries = 4
    while tries > 0:
        time.sleep(5)
        if "Facebook" in driver.title:
            tries = 1
            break
    assert "Facebook" in driver.title
    return driver
    #ready to got


def getPasswd():
    return open("pass.txt").read()
   
   
def main(argv):
    
    utep_users=[]
    f = open('all_cs.txt','r')
    for line in f:
        name = line.split(';')[0]
        if len(name)>1:
            last,first = name.split(',')#TODO may cuase error if a name has a ,
            utep_users.append([last.strip(),first.strip(),line.split(';')[1],line.split(';')[2][:-1]])
    f.close()
    
    
    output= open('all_cs_fb.txt','w')
    fb_users=[]
    html = open('UTEPcs.html','r').read()
    for line in html.split('class="fsl fwb fcb"'):
        name = find_between(line,'<a','</a>')
        name = name[name.rfind('>')+1:]
        pic = find_between(line,'_s0 _rv img" src="','" alt')
        pic = pic.replace('amp;','')
        fb_users.append([name,pic])
        
    count = 0
    for u in utep_users:
        found = False
        for fu in fb_users:
            if (u[0] in fu[0] and u[1] in fu[0]):
                output.write(u[0]+';'+u[1]+';'+u[2]+';'+u[3]+';'+fu[1]+'\n')
                print(u[0],u[1],u[2],u[3],fu[1])
                print ''
                count = count +1
                found=True
                break
        if not found:
            output.write(u[0]+';'+u[1]+';'+u[2]+';'+u[3]+';'+'/cat38.jpg'+'\n')
            print(u[0],u[1],u[2],u[3],'/cat38.jpg')
            print ''
    print count
    output.close()



if __name__ == "__main__":
    main(sys.argv)


