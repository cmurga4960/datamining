# -*- coding: utf-8 -*-
"""
Created on Sat Apr 01 17:18:26 2017

@author: the4960
get rid of 100x100 pics
"""

f = open('base2.txt','r')
out = open('base3.txt','w')

for line in f:
    if 'https://www.facebook.com' in line:
        out.write(line[:-1]+';\n')
    else:
        q = line.split(';')
        index=0
        found = False
        for elem in q:
            if 'https' in elem or found:
                q[index]=''
                found=True
            index=index+1
        if len(q)==5:
            out.write(q[0]+';'+q[1]+';'+q[2]+';'+q[3]+';'+q[4]+';\n')
        if len(q)==6:
            out.write(q[0]+';'+q[1]+';'+q[2]+';'+q[3]+';'+q[4]+';'+q[5]+';\n')