# -*- coding: utf-8 -*-
"""
Created on Sat Apr 01 16:48:04 2017

@author: the4960
fix level ... now fix ruls from first iteration
"""

ok = open('all_cs_fb.txt','r').read().split('\n')
fix = open('all_cs_fb3.txt','r').read().split('\n')
out = open('base2.txt','w')
fix_data=[]



for p in fix:
    fix_data.append(p.split(';'))
for p in ok:
    ok_data=p.split(';')
    found = False
    for q in fix_data:
        if ok_data[0] == q[0] and ok_data[1] == q[1]:
            url=''
            for elem in q:
                if 'https' in elem or len(url):
                    url=url+elem+';'
                    break
            ok_data[-1]=url[:-1]
            found = True
            break
    out.write(ok_data[0]+';'+ok_data[1]+';'+ok_data[2]+';'+ok_data[3]+';'+ok_data[4]+'\n')
    print(ok_data[0]+';'+ok_data[1]+';'+ok_data[2]+';'+ok_data[3]+';'+ok_data[4]+'\n')
out.close()