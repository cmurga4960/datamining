# -*- coding: utf-8 -*-
"""
Created on Fri Mar 31 17:21:52 2017

@author: the4960
utep cs students pics
"""


from selenium import webdriver
from selenium.webdriver.common.keys import Keys
import time
import sys


email = "cmurga4960@gmail.com"
utep_users=[]
output=open('all_cs_fb2.txt','w')

def find_between( s, first, last ):
    try:
        start = s.index( first ) + len( first )
        end = s.index( last, start )
        return s[start:end]
    except ValueError:
        return ""

def loginFB(email,passwd):
    driver = webdriver.Firefox()
    driver.get("http://www.facebook.com/login")
    
    if "Facebook" == driver.title:
        return driver
    login = 'Log into Facebook | Facebook'
    assert login in driver.title
    elem = driver.find_element_by_name("email")
    elem.clear()
    elem.send_keys(email)
    elem = driver.find_element_by_name("pass")
    elem.clear()
    elem.send_keys(passwd)
    elem.send_keys(Keys.RETURN)
    tries = 4
    while tries > 0:
        time.sleep(5)
        if "Facebook" in driver.title:
            tries = 1
            break
    assert "Facebook" in driver.title
    return driver
    #ready to go

#TODO TODO TODO TODO TODO TODO TODO TODO TODO TODO TODO TODO TODO TODO 
#get prof pic from person_url
#TODO TODO TODO TODO TODO TODO TODO TODO TODO TODO TODO TODO TODO TODO 
def fbProfilePic(driver,user):
    url = 'https://www.facebook.com/search/top/?q='+user[1].split(' ')[0]+' '+user[0].split(' ')[0]
    url = url.replace(' ','%20')
    driver.get(url)
    time.sleep(3)    
    
    #temp = open('temp.html','w')
    #temp.write(driver.page_source.encode("utf-8"))
    #temp.close()
    content = driver.page_source.encode("utf-8")#open('temp.html','r').read()
    
    for person in content.split('_2yer'):
        if '<a class="_2yez"' in person:
            person_url = find_between(person,'href="','"')
            print (user,person_url)
            output.write(user[0]+';'+user[1]+';'+user[2]+';'+person_url)
            return driver
            
            
    #if nothing, try without initial
    url = 'https://www.facebook.com/search/top/?q='+user[1]+' '+user[0].split(' ')[0]
    url = url.replace(' ','%20')
    driver.get(url)
    time.sleep(3)
    
    #temp = open('temp.html','w')
    #temp.write(driver.page_source.encode("utf-8"))
    #temp.close()
    content = driver.page_source.encode("utf-8")#open('temp.html','r').read()
    
    for person in content.split('_2yer'):
        if '<a class="_2yez"' in person:
            person_url = find_between(person,'href="','"')
            print(user,person_url)
            output.write(user[0]+';'+user[1]+';'+user[2]+';'+person_url)
            return driver
    return driver

def getPasswd():
    return open("pass.txt").read()
        
    
    
def main(argv):
    driver = loginFB(email,getPasswd())
    
    utep_users=[]
    f = open('all_cs_fb.txt','r')
    for line in f:
        if not ('/cat38.jpg' in line.split(';')[-1]):
            output.write(line)
            continue
        last = line.split(';')[0]
        first = line.split(';')[1]
        utep_users.append([last.strip(),first.strip(),line.split(';')[1],line.split(';')[2][:-1]])
        driver = fbProfilePic(driver,utep_users[-1])
    f.close()
    output.close()
    

if __name__ == "__main__":
    main(sys.argv)


