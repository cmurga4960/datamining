# -*- coding: utf-8 -*-
"""
Created on Sat Apr 01 18:02:32 2017

@author: the4960
get fb pics from profile url
"""
from selenium import webdriver
from selenium.webdriver.common.keys import Keys
import time
import sys

email = "cmurga4960@gmail.com"

def find_between( s, first, last ):
    try:
        start = s.index( first ) + len( first )
        end = s.index( last, start )
        return s[start:end]
    except ValueError:
        return ""
        
        
def loginFB(email,passwd):
    driver = webdriver.Firefox()
    driver.get("http://www.facebook.com/login")
    if "Facebook" == driver.title:
        return driver
    login = 'Log into Facebook | Facebook'
    assert login in driver.title
    elem = driver.find_element_by_name("email")
    elem.clear()
    elem.send_keys(email)
    elem = driver.find_element_by_name("pass")
    elem.clear()
    elem.send_keys(passwd)
    elem.send_keys(Keys.RETURN)
    tries = 4
    while tries > 0:
        time.sleep(5)
        if "Facebook" in driver.title:
            tries = 1
            break
    assert "Facebook" in driver.title
    return driver
    #ready to got

def getProfPic(driver,prof_link):
    print('XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX')
    print(prof_link)
    driver.get(prof_link)
    time.sleep(2)
    page = driver.page_source.encode("utf-8")
    for line in page.split('<img'):
        if 'profilePic img' in line:
            data = find_between(line,'src="','">')
            print 'FOUND STUFF'
            data = data.replace('amp;','')
            return data
    return ''
    
def getPasswd():
    return open("pass.txt").read()
   
   
def main(argv):
    driver = loginFB(email,getPasswd())
    
    f = open('good_base.txt','r')
    output = open('final_users.txt','w')
    for line in f:
        url = getProfPic(driver,line.split(';')[-2])
        print(line+url+'\n')
        output.write(line+url+'\n')
    output.close()
        
if __name__ == "__main__":
    main(sys.argv)


