# -*- coding: utf-8 -*-
"""
Created on Fri Mar 31 14:07:35 2017

@author: the4960
"""


import requests
import time
#https://adminapps.utep.edu/campusdirectory/People/All


def find_between( s, first, last ):
    try:
        start = s.index( first ) + len( first )
        end = s.index( last, start )
        return s[start:end]
    except ValueError:
        return ""

vowls = {'a':20540,'e':18130,'i':15390,'o':13740,'u':6830,'y':3580}
#a=27246,20540 students
#e=24014,18130
#i=20495,15390
#o=18297,13740
#u=9135,6830
#y=4860,3580


#293 people left e.e
#https://adminapps.utep.edu/campusdirectory/People/All
#epcc http://www.epcc.edu/Search/Directory/Pages/default.aspx

letter = ord('a')
output = open('all_cs_'+chr(letter)+'.txt','a')
print chr(letter)
for page in range(0,vowls[chr(letter)]+20,10):
    time.sleep(2)
    url = "https://adminapps.utep.edu/campusdirectory/People/Students/"+str(page)+"?queryString="+chr(letter)+"#results"
    print (url)
    try:
        response = requests.get(url)
    except:
        print('EERRRRRRRRRRORRRRR:',page,url)
        continue
    if response.status_code != 200:
        print 'GOT ! 200'
        break
    for student in response.content.split('<article class="directory-item">'):
        cs=False
        name=''
        email=''
        level=''
        for line in student.split('\n'):
            if 'mailto:' in line:
                email = find_between(line,'"mailto:','">')
                
            if 'directory-item-title' in line:
                name = find_between(line,'title">','</h3>')
                
            if 'Classification and Major' in line:
                cs = 'Computer Science' in line
                level = find_between(line,'Classification and Major</span> ',':')
        if cs and name and email and level:
            print(name+';'+level+';'+email+'\n')
            output.write(name+';'+level+';'+email+'\n')
    
output.close()
print 'END'









